function likesUp(id){
    var element = document.querySelector(`#${id}`);
    element.innerText++;
}